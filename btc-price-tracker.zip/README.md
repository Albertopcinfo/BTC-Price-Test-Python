# 🪙 BTC Price Tracker (Python)

Script sencillo en Python para seguir el **precio de Bitcoin (BTC/USD)** en tiempo real usando la API pública de [CoinGecko](https://www.coingecko.com/).

## 🚀 Cómo usarlo

1. Clona este repositorio:
   ```bash
   git clone https://github.com/tuusuario/btc-price-tracker.git
   cd btc-price-tracker
   ```

2. Instala las dependencias:
   ```bash
   pip install -r requirements.txt
   ```

3. Ejecuta el script:
   ```bash
   python btc_tracker.py
   ```

El precio se actualizará cada 10 segundos en tu consola 💹  
Presiona `Ctrl + C` para detenerlo.

## ⚙️ Personalización

Puedes cambiar:
- La frecuencia de actualización (`time.sleep(10)`)
- La moneda (`vs_currencies=eur` por ejemplo)
- O incluso conectar con otra API (Binance, Coinbase, etc.)

## 🧑‍💻 Autor
Creado por [tuusuario](https://github.com/tuusuario) — proyecto educativo y de seguimiento personal.
