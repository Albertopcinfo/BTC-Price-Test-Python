import requests
import time
import datetime
import os

API_URL = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd"

def get_btc_price():
    try:
        response = requests.get(API_URL, timeout=10)
        response.raise_for_status()
        data = response.json()
        return data["bitcoin"]["usd"]
    except requests.RequestException as e:
        print(f"Error al obtener precio: {e}")
        return None

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

def main():
    print("=== Seguimiento del precio de Bitcoin (BTC/USD) ===")
    print("Presiona Ctrl + C para salir\n")
    
    while True:
        price = get_btc_price()
        if price:
            clear_console()
            print("=== Seguimiento del precio de Bitcoin (BTC/USD) ===")
            print(f"🕒 {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            print(f"💰 Precio actual: ${price:,.2f} USD")
        else:
            print("No se pudo obtener el precio, reintentando...")

        time.sleep(10)

if __name__ == "__main__":
    main()
